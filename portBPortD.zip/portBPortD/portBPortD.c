void main() {
     //Clear I/O
     PORTB=0x00;
     PORTD=0x00;
     //PortB As Input
     TRISB=0xFF;
     //PortD As Output
     TRISD=0x00;
     //Turn On Weak Pullup Resistor Of PortB
     OPTION_REG.F7=0;
     while(1){
      //Read Digital Data Input From PortB
      PORTD=PORTB;
      //Wait a few milli seconds
      delay_ms(3);
     }
}