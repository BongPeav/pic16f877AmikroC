
#define MOTOR PORTB.RB5         // Motor Connected to RB5
#define Period 20               // MAX TIME IS 20ms
bit run_stop;
char speed;

void interrupt() {
     if(INTCON.RBIF)
     {
       if(PORTB.RB2^1)  { run_stop^=1; delay_ms(200); }
       if(PORTB.RB1^1)  if(speed>0)  speed--;
       if(PORTB.RB0^1)  if(speed<20) speed++;
     }
     INTCON.RBIF=0;
     }

void motor()
{    char ON,OFF;
     ON=Period-speed;
     OFF=Period-ON;
     if(run_stop) {
        MOTOR=1;
        Vdelay_ms(ON);
        MOTOR=0;
        Vdelay_ms(OFF);
        }
}

void main() {
     speed=20;
     run_stop=0;
     PORTB=0x00;                // CLEAR PORTB
     TRISB=0x07;                 // RB0-RB2 ARE INPUTS
     ANSELH=0x00;                // DISABLE ALL ANALOG FUNCTION
     OPTION_REG.F7=0;            // ENABLE WPUB
     WPUB=0x07;               // TURN ON WPUB FOR RB0-RB2
     OSCCON|=0x70;            // SELECT INTRCIO 8MHz
     INTCON.GIE=1;            // TURN ON GLOBAL INTERRUPT
     INTCON.RBIE=1;           // TURN ON IOCB
     IOCB=0x07;               // RB0-RB2 USE TO CREATE INTERRUPT
     INTCON.RBIF=0;           // CLEAR INTERRUPT FLAG
     while(1)
     motor();
}